import os
from utils import print_banner, t, build_custom_command
from config import options_map

def main():
    print_banner()

    lang = input("اختر اللغة [ar/en]: ").strip().lower()
    if lang not in ["ar", "en"]:
        lang = "en"

    print(t("\nأنواع الفحص:", "\nScan Types:", lang))
    print("1. " + t("فحص سريع", "Fast Scan", lang))
    print("2. " + t("فحص شامل", "Full Scan", lang))
    print("3. " + t("فحص ثغرات", "Vulnerability Scan", lang))
    print("4. " + t("فحص الشبكة", "Network Sweep", lang))
    print("5. " + t("مخصص", "Custom Scan", lang))

    choice = input(t("اختر رقم الفحص: ", "Select scan number: ", lang)).strip()

    if choice != "5":
        target = input(t("أدخل الهدف: ", "Enter target: ", lang)).strip()
        if choice == "1":
            cmd = f"nmap -F {target}"
        elif choice == "2":
            cmd = f"nmap -A -T4 {target}"
        elif choice == "3":
            cmd = f"nmap --script vuln {target}"
        elif choice == "4":
            cmd = f"nmap -sn {target}"
        else:
            print(t("خيار غير معروف.", "Unknown option.", lang))
            return
    else:
        target = input(t("أدخل الهدف: ", "Enter target: ", lang)).strip()
        print(t("\nاختر أرقام الخيارات مفصولة بفاصلة:", "\nSelect option numbers separated by comma:", lang))
        for key, val in options_map.items():
            label = t("الخيار", "Option", lang)
            print(f"{key}. {label} {val}")
        selected = input(t("أدخل الأرقام (مثال 1,3,5): ", "Enter option numbers (e.g. 1,3,5): ", lang))
        choices = selected.split(",")
        cmd = build_custom_command(choices, options_map, lang, target)

    print(t("\nتنفيذ الأمر:", "\nRunning command:", lang))
    print(cmd)
    os.system(cmd)

if __name__ == "__main__":
    while True:
        main()
