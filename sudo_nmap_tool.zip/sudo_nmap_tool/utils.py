import pyfiglet

def print_banner():
    banner = pyfiglet.figlet_format("SUDO Nmap Tool")
    print(banner)
    print("Developed by: sudo\n")

def t(ar, en, lang):
    return ar if lang == "ar" else en

def build_custom_command(choices, options_map, lang, target):
    parts = []
    for choice in choices:
        key = choice.strip()
        if key not in options_map:
            continue
        opt = options_map[key]
        if opt == "-p":
            ports = input(t("أدخل المنافذ (مثال: 80,443): ", "Enter ports (e.g. 80,443): ", lang))
            parts.append(f"-p {ports}")
        elif opt == "-A -oN":
            filename = input(t("أدخل اسم ملف الحفظ: ", "Enter output filename: ", lang))
            parts.append(f"-A -oN {filename}")
        elif opt == "custom":
            custom = input(t("أدخل أوامر مخصصة: ", "Enter custom options: ", lang))
            parts.append(custom)
        elif opt == "-S":
            spoof_ip = input(t("IP وهمي؟ ", "Spoofed IP: ", lang))
            parts.append(f"-S {spoof_ip}")
        elif opt == "multiple":
            targets = input(t("أدخل أهداف متعددة: ", "Enter multiple targets: ", lang))
            return f"nmap {' '.join(parts)} {targets}"
        elif opt == "--script":
            script = input(t("نوع سكربت NSE: ", "NSE script type: ", lang))
            parts.append(f"--script {script}")
        elif opt == "timing":
            timing = input(t("سرعة (T0-T5): ", "Timing (T0-T5): ", lang))
            parts.append(f"-{timing}")
        elif opt == "--spoof-mac":
            mac = input(t("أدخل MAC وهمي: ", "Enter fake MAC address: ", lang))
            parts.append(f"--spoof-mac {mac}")
        elif opt == "output":
            fmt = input(t("اختر xml أو html: ", "Choose xml or html: ", lang)).lower()
            if fmt == "xml":
                parts.append("-oX result.xml")
            elif fmt == "html":
                parts.append("-oX result.xml && xsltproc result.xml -o result.html")
        else:
            parts.append(opt)
    return f"nmap {' '.join(parts)} {target}"
